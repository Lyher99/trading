# Forex Trading Bot

An automated trading bot for MetaTrader 5 that implements a moving average crossover strategy with RSI and MACD filters.

## Features

- Automated trading on MetaTrader 5
- Moving Average Crossover strategy
- RSI and MACD filters for better entry/exit points
- Real-time market data analysis
- Position management with stop-loss and take-profit
- Logging system for monitoring and debugging
- Optional Telegram notifications

## Prerequisites

- Python 3.8 or higher
- MetaTrader 5 terminal installed and configured
- A broker account with MT5 access
- (Optional) Telegram bot token and chat ID for notifications

## Installation

1. Clone this repository:
```bash
git clone <repository-url>
cd <repository-directory>
```

2. Install required packages:
```bash
pip install -r requirements.txt
```

3. Copy the environment example file and configure your settings:
```bash
cp .env.example .env
```

4. Edit the `.env` file with your MT5 credentials and trading parameters.

## Usage

1. Make sure MetaTrader 5 is running and you're logged in.

2. Run the trading bot:
```bash
python trading_bot.py
```

## Strategy Details

The bot implements a combination of technical indicators:

- Moving Average Crossover (20 and 50 periods)
- RSI (14 periods) for overbought/oversold conditions
- MACD for trend confirmation

### Entry Rules
- Buy when short MA crosses above long MA
- Sell when short MA crosses below long MA
- RSI must not be in extreme zones (>70 or <30)
- MACD must confirm the trend direction

### Exit Rules
- Close long positions when RSI > 70 or MACD crosses below signal line
- Close short positions when RSI < 30 or MACD crosses above signal line

## Risk Warning

Trading forex involves significant risk of loss. This bot is provided for educational purposes only. Always test thoroughly in a demo account before using with real money.

## License

This project is licensed under the MIT License - see the LICENSE file for details. 